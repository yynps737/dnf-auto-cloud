DNF自动化客户端

安装说明:
1. 安装Python 3.8或更高版本
2. 安装依赖包:
   pip install pillow numpy websockets keyboard mouse pywin32 mss

3. 编辑config.ini设置服务器地址
4. 运行start.bat启动客户端
